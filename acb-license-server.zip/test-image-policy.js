const fs = require('fs'), vm = require('vm');
const src = fs.readFileSync('./routes/generate.js', 'utf8');
const ctx = { console };
vm.createContext(ctx);
const IMAGE_MODEL='gpt-image-1.5', IMAGE_SIZE='1536x1024', IMAGE_QUALITY='medium';
const blocks = [
  `const IMAGE_MODEL='${IMAGE_MODEL}', IMAGE_SIZE='${IMAGE_SIZE}', IMAGE_QUALITY='${IMAGE_QUALITY}';`,
  src.match(/const IMAGE_POLICY = \{[\s\S]*?\};/)[0],
  src.match(/const DEFAULT_IMAGE_POLICY = \{[^}]*\};/)[0],
  src.match(/function imagePolicyFor\(tier\) \{[\s\S]*?\n\}/)[0],
  src.match(/function localeClause\(gl\) \{[\s\S]*?\n\}/)[0],
];
vm.runInContext(blocks.join('\n'), ctx);
const { imagePolicyFor, localeClause } = ctx;

const pricing = require('./lib/pricing.js');
let pass=0, fail=0;
const ok=(l,c)=>c?(pass++,console.log('  ok  ',l)):(fail++,console.error('  FAIL',l));

console.log('imagePolicyFor:');
ok('free -> mini', imagePolicyFor('free').model==='gpt-image-1-mini');
ok('pro -> full 1.5', imagePolicyFor('pro').model==='gpt-image-1.5');
ok('agency -> full 1.5', imagePolicyFor('agency').model==='gpt-image-1.5');
ok('starter -> full 1.5', imagePolicyFor('starter').model==='gpt-image-1.5');
ok('unknown tier -> paid default (fail safe)', imagePolicyFor('enterprise').model==='gpt-image-1.5');
ok('empty tier -> paid default', imagePolicyFor('').model==='gpt-image-1.5');

console.log('every policy prices in lib/pricing.js:');
const POLICIES = {free:imagePolicyFor('free'),starter:imagePolicyFor('starter'),pro:imagePolicyFor('pro'),agency:imagePolicyFor('agency')};
for (const [tier,p] of Object.entries(POLICIES)) {
  if (!p.model) { ok(`${tier} no-image -> $0`, pricing.imageCostUsd(p)===0); continue; }
  ok(`${tier} (${p.model}|${p.size}|${p.quality}) -> real price`, typeof pricing.imageCostUsd(p)==='number' && pricing.imageCostUsd(p)>0);
}
ok('free mini medium = $0.015', pricing.imageCostUsd(imagePolicyFor('free'))===0.015);
ok('pro full medium = $0.050', pricing.imageCostUsd(imagePolicyFor('pro'))===0.05);

console.log('localeClause (subtractive):');
const uk = localeClause('gb'), us = localeClause('us');
ok('UK non-empty', uk.length>0);
ok('UK does NOT command "set in the United Kingdom"', !/set in the United Kingdom/i.test(uk));
ok('UK bans flags + landmarks', /national flags/i.test(uk) && /landmarks/i.test(uk));
ok('UK steers away from American look', /American/i.test(uk));
ok('US has no anti-American steer', !/American/i.test(us));
ok('US still bans flags/landmarks', /national flags/i.test(us));
ok('unknown gl -> empty', localeClause('zz')==='');
ok('no cliché tokens in UK clause', !/phone box|union jack|routemaster|red bus|post box/i.test(uk));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail?1:0);
